import java.util.Scanner;

public class CaixaEletronico {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double saldo = 1000.00;

        System.out.print("Digite o valor do saque: R$ ");
        double saque = scanner.nextDouble();

        if (saque <= saldo) {
            System.out.println("Saque realizado com sucesso");
        } else {
            System.out.println("Saldo insuficiente");
        }

        scanner.close();
    }
}
