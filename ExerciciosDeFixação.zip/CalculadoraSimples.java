import java.util.Scanner;

public class CalculadoraSimples {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o primeiro número: ");
        double primeiro = scanner.nextDouble();

        System.out.print("Digite o segundo número: ");
        double segundo = scanner.nextDouble();

        System.out.print("Digite a operação (+, -, * ou /): ");
        char operacao = scanner.next().charAt(0);

        double resultado;

        if (operacao == '+') {
            resultado = primeiro + segundo;
            System.out.println("Resultado: " + resultado);
        } else if (operacao == '-') {
            resultado = primeiro - segundo;
            System.out.println("Resultado: " + resultado);
        } else if (operacao == '*') {
            resultado = primeiro * segundo;
            System.out.println("Resultado: " + resultado);
        } else if (operacao == '/') {
            if (segundo == 0) {
                System.out.println("Erro: não é possível dividir por zero.");
            } else {
                resultado = primeiro / segundo;
                System.out.println("Resultado: " + resultado);
            }
        } else {
            System.out.println("Operação inválida.");
        }

        scanner.close();
    }
}
