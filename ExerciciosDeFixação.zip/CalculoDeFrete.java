import java.util.Scanner;

public class CalculoDeFrete {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o valor da compra: R$ ");
        double valorCompra = scanner.nextDouble();

        double frete;

        if (valorCompra >= 200) {
            frete = 0;
        } else {
            frete = 20;
        }

        System.out.printf("Valor do frete: R$ %.2f%n", frete);

        scanner.close();
    }
}
