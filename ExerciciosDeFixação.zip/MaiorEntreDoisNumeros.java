import java.util.Scanner;

public class MaiorEntreDoisNumeros {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o primeiro número: ");
        double primeiro = scanner.nextDouble();

        System.out.print("Digite o segundo número: ");
        double segundo = scanner.nextDouble();

        if (primeiro > segundo) {
            System.out.println("Maior número: " + primeiro);
        } else {
            System.out.println("Maior número: " + segundo);
        }

        scanner.close();
    }
}
