import java.util.Scanner;

public class ClassificacaoDeTemperatura {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite a temperatura em graus Celsius: ");
        double temperatura = scanner.nextDouble();

        if (temperatura >= 25) {
            System.out.println("Clima quente");
        } else {
            System.out.println("Clima ameno");
        }

        scanner.close();
    }
}
