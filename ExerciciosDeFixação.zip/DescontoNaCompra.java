import java.util.Scanner;

public class DescontoNaCompra {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o valor da compra: R$ ");
        double valor = scanner.nextDouble();

        double valorFinal;

        if (valor >= 100) {
            valorFinal = valor * 0.90;
        } else {
            valorFinal = valor;
        }

        System.out.printf("Valor final da compra: R$ %.2f%n", valorFinal);

        scanner.close();
    }
}
